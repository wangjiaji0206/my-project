from django.db import models
import PIL
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    name = models.CharField(max_length=32)
    password = models.CharField(max_length=64)
    age = models.IntegerField()
    sex=models.CharField(max_length=32)
    department=models.CharField(max_length=32)
    info=models.TextField(null=True)
    # 对gender做约束
    # gender_choices=(
    #     (1,"男"),
    #     (2,"女"),
    # )
    # gender=models.SmallIntegerField(verbose_name="性别",choices=gender_choices,default="")
    # USERNAME_FIELD = 'password'


class Album(models.Model):
    name = models.CharField(max_length=32)
    description = models.CharField(max_length=200, null=True)
    cover = models.ImageField(null=True)
    belongU = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)


class IMG(models.Model):
    img = models.ImageField(upload_to='img')
    name = models.CharField(max_length=200)
    belongA = models.ForeignKey(Album, on_delete=models.CASCADE, null=True)


"""帖子表"""
# 有约束
# to表示与哪张表关联
# to_field表示与表中的哪一列关联
# 外键的某个id被删除，采取级联删除法，on_delete=models.CASCADE
class Article(models.Model):
    belongU = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    # aid = models.BigAutoField(primary_key=True,default="")
    header=models.TextField(null=True);
    body = models.TextField(null=True);
    view_count = models.IntegerField()
    kind=models.CharField(max_length=32)
    comment_count =models.IntegerField()
    # create_time=models.DateTimeField(verbose_name="帖子发送时间",default="")

"""评论表"""
class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    article=models.ForeignKey(Article, on_delete=models.CASCADE, null=True)
    # context = models.CharField(max_length=2000)
    body = models.TextField(null=True)
    # created = models.DateTimeField(auto_now_add=True, null=True)
    # def __str__(self):
    #     return self.body[0:50]



