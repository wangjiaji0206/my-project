from django.shortcuts import render, HttpResponse, redirect
from app01.models import IMG
from django.contrib import messages
from app01 import models
from app01.models import User, Album, Comment
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q


# Create your views here.


def user_list(request):
    return render(request, "user_list.html")


def loginPage(request):
    if request.user.is_authenticated:
        context = {'username': request.user.username}
        print(request.user.username)
        return render(request, 'main.html', context)
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
        user = None
        try:
            user = User.objects.get(username=username)

        except:
            print("不存在")
            # messages.error(request,'')

        authenticate(request, username=username, password=password)
        if user is not None:

            login(request, user)
            context = {'username': request.user.username}
            # return render(request, "main.html",context)
            return redirect('main')
        else:
            messages.error(request, '密码错误')
            print('慢慢吃')

    return render(request, 'login.html')


def logoutUser(request):
    logout(request)
    return redirect('main')


def orm(request):
    # 1.新建数据
    # Department.objects.create(title="销售部")
    # Department.objects.create(title="IT部")
    # Department.objects.create(title="运营部")
    # User.objects.create(name="王甲基",password=123456,age=20)
    User.objects.create(name="董帅帅", password=123456, age=20)
    User.objects.create(name="黄艺杰", password=123456, age=20)
    # 2.删除数据
    # Department.objects.filter(id=3).delete()
    # Department.objects.all().delete()
    # 3.获取数据
    # data_list=Department.objects.all()
    # for obj in data_list:
    #     print(obj.id,obj.title)
    # row_list=Department.objects.filter(id=22).first();
    # print(row_list.id,row_list.title)
    # 4.更新数据
    # Department.objects.all().update(title="IT部")
    # Department.objects.filter(id=22).update(title="销售部")
    return HttpResponse("成功")


def info_delete(request):
    nid = request.GET.get("nid")
    User.objects.filter(id=nid).delete()
    return redirect("/info/list")


def photo_list(request):
    content = request.GET.get('content')

    if content is not None:
        photos = IMG.objects.filter(name__icontains=content)
        context = {'photos': photos}
        return render(request, 'Search_Result.html', context)
    imgs = IMG.objects.all()
    current_user_name = request.user.username
    content = {
        'imgs': imgs,
        'username': current_user_name,
    }
    # print(imgs[0].img.url)
    return render(request, "photo_list.html", content)

def article_add(request):
    if (request.method=="GET"):
        return render(request,'article_add.html')
    header=request.POST.get("header")
    article=request.POST.get("article")
    kind=request.POST.get("kind")
    id=request.user
    print(article)
    models.Article.objects.create(belongU=id,header=header,body=article,view_count=0,kind=kind,comment_count=0)
    return redirect("main")

def info(request):
    if (request.method == "GET"):
        return render(request, 'info.html')
    sex = request.POST.get("sex")
    age=request.POST.get("age")
    department = request.POST.get("department")
    info=request.POST.get("info")
    id=request.user.id
    print(info)
    models.User.objects.filter(id=id).update(age=age,sex=sex,department=department,info=info)
    return redirect("http://127.0.0.1:8000/user/page/")

def article_view(request):
    nid=request.GET.get('nid')
    article=models.Article.objects.filter(id=nid)
    view_count=article.first().view_count+1
    article.update(view_count=view_count)
    print(type(article))
    print(article)
    if request.method=="POST":
        comment=request.POST.get("comment")
        uid=request.user
        for i in article:
            aid=i
        models.Comment.objects.create(user=uid,article=aid,body=comment)
        comment_count=article.first().comment_count+1
        article.update(comment_count=comment_count)
    comments=models.Comment.objects.filter(article=nid)
    # if comments is not None:
    #     context = {'article': article, 'comments': comments}
    context = {'article': article, 'comments': comments}
    return render(request,"article_view.html",context)

def user_page(request):
    article = models.Article.objects.filter(belongU=request.user)
    # user=models.User.objects.filter(id=request.user)
    return render(request,"user_page.html",{'article':article})

def article_delete(request):
    nid = request.GET.get('nid')
    models.Article.objects.filter(id=nid).delete()
    return redirect("http://127.0.0.1:8000/user/page")

def hot_list(request):
    # models.Article.objects.order_by("view_count")
    hotlist=models.Article.objects.order_by("-view_count")
    return  render(request,"hot_list.html",{"hotlist":hotlist})

def lost(request):
    select=models.Article.objects.filter(kind="失物招领")
    return render(request, "lost.html", {"select": select})

def news(request):
    select = models.Article.objects.filter(kind="校内新闻")
    return render(request, "news.html", {"select": select})

def notice(request):
    select = models.Article.objects.filter(kind="重要通知")
    return render(request, "notice.html", {"select": select})

def main(request):
    # if request.method=='POST':
    content = request.GET.get('content')

    if content is not None:
        result =models.Article.objects.filter(header=content)
        context = {'result': result}
        return render(request, 'Search_Result.html', context)
    if request.user.id is None:
        return render(request, "main.html", {'content': '登录查看更多内容'})
    queryset=models.Article.objects.all()

    return render(request, "main.html", {"queryset": queryset})



def photo_add(request, pk):
    if request.method == "GET":
        return render(request, "photo_add.html")
    # 获取用户提交的数据

    # 添加到数据库
    if request.method == 'POST':
        new_img = IMG(
            img=request.FILES.get('img'),
            name=request.POST.get('name'),
            belongA=Album.objects.get(id=pk)
        )

        new_img.save()
        return redirect("http://127.0.0.1:8000/photo/list")


def uploadImg(request):
    """
    图片上传
    :param request:
    :return:
    """
    if request.method == 'POST':
        new_img = IMG(
            img=request.FILES.get('img'),
            name=request.FILES.get('img').name
        )

        new_img.save()
        return redirect("http://127.0.0.1:8000/photo/list")

    return render(request, 'uploading.html')


def showImg(request):
    """
    图片显示
    :param request:
    :return:
    """
    imgs = IMG.objects.all()
    content = {
        'imgs': imgs,
    }
    for i in imgs:
        print(i.img.url)
    return render(request, 'showing.html', content)


def register(request):
    if request.method == 'GET':
        return render(request, "register.html")
        # print(request.POST)
    elif request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        print(username, password1, password2)
        if password1 != password2:
            messages.error(request, '两次输入密码不一致')
            return render(request, 'register.html')

        try:
            user = User.objects.get(name=username)
            if user != None:
                print('用户已经存在')
                messages.error(request, '用户已经存在')
                return redirect('http://127.0.0.1:8000/login')
        except:
            models.User.objects.create(username=username, password=password1, age=18,sex="未知",department="未知",info="无",name=username)
            return redirect('http://127.0.0.1:8000/login')

    return render(request, 'register.html')


def album_delete(request, pk):
    album = Album.objects.get(id=pk)
    album.delete()
    return redirect('main')


def Search():
    return render('Search_Result.html')


def comment_delete(request, pk):
    comment = Comment.objects.filter(id=pk)
    comment.delete()

    return redirect('main')




