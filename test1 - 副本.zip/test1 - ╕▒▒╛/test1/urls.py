"""test1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.http import HttpResponse
from django.urls import path
from app01 import views

urlpatterns = [
    # path("admin/", admin.site.urls),
    path('',views.loginPage),
    path('index/',views.user_list),
    path('login/',views.loginPage,name='login'),
    path('orm/',views.orm),
    path('info/delete/',views.info_delete),
    path('photo/list/',views.photo_list),
    path('main/',views.main,name='main'),
    path('upload/', views.uploadImg),
    path('show/', views.showImg),
    path('register/',views.register,name='register'),
    path('logout/',views.logoutUser),
    path('album/delete/<str:pk>',views.album_delete,name="albumDelete"),
    path('search/<str:pk>',views.Search,name='Search'),
    path('comment/delete/<str:pk>',views.comment_delete,name="comment_delete"),
    path('article/add/',views.article_add),
    path('article/detail/',views.article_view),
    path('user/page/',views.user_page),
    path('article/delete/',views.article_delete),
    path('hot_list/',views.hot_list),
    path('lost/',views.lost),
    path('news/',views.news),
    path('notice/',views.notice),
    path('info/',views.info)
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
